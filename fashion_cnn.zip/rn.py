import torch
from torchvision.models import resnet18, ResNet18_Weights
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader


# =========================================================
# Device (CPU only)
# =========================================================
device = torch.device("cpu")


# =========================================================
# Load pretrained ResNet18
# =========================================================
weights = ResNet18_Weights.DEFAULT

model = resnet18(weights=weights)

model = model.to(device)
model.eval()


# =========================================================
# CIFAR-10 Labels
# =========================================================
cifar10_classes = [
    "airplane",
    "automobile",
    "bird",
    "cat",
    "deer",
    "dog",
    "frog",
    "horse",
    "ship",
    "truck"
]


# =========================================================
# Image Transform
# =========================================================
# ResNet18 expects 224x224 ImageNet normalization

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])


# =========================================================
# Load CIFAR-10 Test Dataset
# =========================================================
test_dataset = torchvision.datasets.CIFAR10(
    root="./data",
    train=False,
    download=True,
    transform=transform
)

test_loader = DataLoader(
    test_dataset,
    batch_size=1,
    shuffle=True
)


# =========================================================
# Predict Some Images
# =========================================================
imagenet_labels = weights.meta["categories"]

correct = 0
total = 0

with torch.no_grad():

    for i, (images, labels) in enumerate(test_loader):

        images = images.to(device)

        outputs = model(images)

        predicted = outputs.argmax(1).item()

        cifar_label = cifar10_classes[labels.item()]
        imagenet_prediction = imagenet_labels[predicted]

        print(f"\nImage {i+1}")
        print("CIFAR-10 label:", cifar_label)
        print("ImageNet prediction:", imagenet_prediction)

        # crude matching
        if cifar_label in imagenet_prediction.lower():
            correct += 1

        total += 1

        # only show first 20 images
        if i >= 19:
            break


print("\nApproximate matches:", correct, "/", total)