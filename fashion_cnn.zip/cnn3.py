import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms


# =========================================================
# Device (CPU only)
# =========================================================
device = torch.device("cpu")


# =========================================================
# Classes
# =========================================================
classes = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]


# =========================================================
# CNN Model
# =========================================================
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()

        self.features = nn.Sequential(
            nn.Conv2d(1, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64 * 7 * 7, 128),
            nn.ReLU(),
            nn.Linear(128, 10)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


# =========================================================
# Data
# =========================================================
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

train_dataset = torchvision.datasets.FashionMNIST(
    root="./data",
    train=True,
    download=True,
    transform=transform
)

test_dataset = torchvision.datasets.FashionMNIST(
    root="./data",
    train=False,
    download=True,
    transform=transform
)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)


# =========================================================
# Model, Loss, Optimizer
# =========================================================
model = CNN().to(device)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)


# =========================================================
# Training
# =========================================================
epochs = 3  # CPU-friendly

for epoch in range(epochs):

    model.train()

    running_loss = 0
    correct = 0
    total = 0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()

        outputs = model(images)
        loss = criterion(outputs, labels)

        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    print(
        f"Epoch {epoch+1}: "
        f"Loss={running_loss:.3f}, "
        f"Train Acc={100*correct/total:.2f}%"
    )


# =========================================================
# Save model
# =========================================================
torch.save(model.state_dict(), "fashion_cnn.pth")
print("Model saved!")


# =========================================================
# Load model (simulate fresh start)
# =========================================================
loaded_model = CNN().to(device)
loaded_model.load_state_dict(torch.load("fashion_cnn.pth", map_location="cpu"))
loaded_model.eval()


# =========================================================
# Inference
# =========================================================
with torch.no_grad():

    correct = 0
    total = 0

    for i, (images, labels) in enumerate(test_loader):

        outputs = loaded_model(images)

        predicted = outputs.argmax(1)

        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    print("\nTest Accuracy:", 100 * correct / total)


# =========================================================
# Predict single samples
# =========================================================
with torch.no_grad():

    for i, (images, labels) in enumerate(test_loader):

        outputs = loaded_model(images)

        preds = outputs.argmax(dim=1)

        for j in range(len(preds)):
            print("\nTrue:", classes[labels[j].item()])
            print("Pred:", classes[preds[j].item()])

        if i == 0:  # only first batch (64 images)
            break