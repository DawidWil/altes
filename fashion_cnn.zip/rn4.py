import torch
import torch.nn as nn
from torch.utils.data import DataLoader

import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18, ResNet18_Weights


# =========================================================
# Device
# =========================================================
device = torch.device("cpu")
print("Using device:", device)


# =========================================================
# Classes
# =========================================================
classes = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]


# =========================================================
# Load pretrained ResNet18
# =========================================================
weights = ResNet18_Weights.DEFAULT
model = resnet18(weights=weights)


# =========================================================
# Freeze ALL layers except final layer
# =========================================================
for param in model.parameters():
    param.requires_grad = False


# Replace classifier (trainable)
model.fc = nn.Linear(model.fc.in_features, 10)


# Only fc is trainable
for param in model.fc.parameters():
    param.requires_grad = True


model = model.to(device)


# =========================================================
# Transform (Fashion-MNIST -> ImageNet format)
# =========================================================
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.Grayscale(num_output_channels=3),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])


# =========================================================
# Dataset
# =========================================================
train_dataset = torchvision.datasets.FashionMNIST(
    root="./data",
    train=True,
    download=True,
    transform=transform
)

test_dataset = torchvision.datasets.FashionMNIST(
    root="./data",
    train=False,
    download=True,
    transform=transform
)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)


# =========================================================
# Loss + Optimizer (ONLY final layer)
# =========================================================
criterion = nn.CrossEntropyLoss()

optimizer = torch.optim.Adam(model.fc.parameters(), lr=0.001)


# =========================================================
# Training (fast on CPU)
# =========================================================
epochs = 3

for epoch in range(epochs):

    model.train()

    total_loss = 0
    correct = 0
    total = 0

    for images, labels in train_loader:

        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()

        outputs = model(images)
        loss = criterion(outputs, labels)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        preds = outputs.argmax(1)
        correct += (preds == labels).sum().item()
        total += labels.size(0)

    print(
        f"Epoch {epoch+1}: "
        f"Loss={total_loss:.3f}, "
        f"Train Acc={100*correct/total:.2f}%"
    )


# =========================================================
# Evaluation
# =========================================================
model.eval()

correct = 0
total = 0

with torch.no_grad():
    for images, labels in test_loader:

        outputs = model(images)
        preds = outputs.argmax(1)

        correct += (preds == labels).sum().item()
        total += labels.size(0)

print("\nTest Accuracy:", 100 * correct / total)


# =========================================================
# Save model
# =========================================================
torch.save(model.state_dict(), "fashion_resnet_fc.pth")
print("Model saved!")


# =========================================================
# Example predictions
# =========================================================
model.eval()

with torch.no_grad():

    for i, (images, labels) in enumerate(test_loader):

        outputs = model(images)
        preds = outputs.argmax(1)

        print("\nTrue:", classes[labels[0].item()])
        print("Pred:", classes[preds[0].item()])

        if i >= 19:
            break