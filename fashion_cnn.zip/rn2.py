import torch
import torch.nn as nn
from torch.utils.data import DataLoader

import torchvision
import torchvision.transforms as transforms
from torchvision.models import resnet18, ResNet18_Weights


# =========================================================
# Device
# =========================================================
device = torch.device("cpu")
print("Using device:", device)


# =========================================================
# Fashion-MNIST Classes
# =========================================================
classes = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot"
]


# =========================================================
# Load Pretrained ResNet18
# =========================================================
weights = ResNet18_Weights.DEFAULT

model = resnet18(weights=weights)

# Replace final layer for Fashion-MNIST
model.fc = nn.Linear(model.fc.in_features, 10)

# OPTIONAL:
# random weights for final layer only
# no training happens in this script

model = model.to(device)
model.eval()


# =========================================================
# Transform
# =========================================================
# Fashion-MNIST:
# - grayscale 28x28
# ResNet18 expects:
# - RGB 224x224

transform = transforms.Compose([

    # convert 28x28 -> 224x224
    transforms.Resize((224, 224)),

    # grayscale -> 3 channels
    transforms.Grayscale(num_output_channels=3),

    transforms.ToTensor(),

    # ImageNet normalization
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])


# =========================================================
# Dataset
# =========================================================
test_dataset = torchvision.datasets.FashionMNIST(
    root="./data",
    train=False,
    download=True,
    transform=transform
)

test_loader = DataLoader(
    test_dataset,
    batch_size=1,
    shuffle=True
)


# =========================================================
# Inference
# =========================================================
with torch.no_grad():

    for i, (images, labels) in enumerate(test_loader):

        images = images.to(device)

        outputs = model(images)

        predicted = outputs.argmax(1).item()

        print(f"\nImage {i+1}")
        print("True label:", classes[labels.item()])
        print("Predicted:", classes[predicted])

        # show only first 20 images
        if i >= 19:
            break